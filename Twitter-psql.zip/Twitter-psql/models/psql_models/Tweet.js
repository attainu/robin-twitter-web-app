const client = require('../connection/psql');
const login_user = require('../../controllers/User controller/login')
const email = require('../../controllers/User controller/login')
const express = require('express-session');
const { json } = require('body-parser');
const auth = require('../../routes/auth/auth/index')

const user=function (req, res, next) {
    auth
        client.query('CREATE TABLE IF NOT EXISTS twitter_post(id BIGSERIAL NOT NULL PRIMARY KEY,post VARCHAR(500))',function(err,result){
            if(err){
                console.log(err)
                res.status(404).json({
                    message:"Table creation Error",
                    error:{err},
                })
               }
             else{
               res.status(200).json({
                   message:"Table created Successfully",
                   error:{err}
               })
             }
            }
         )
          }

module.exports = user