const client = require('../../connection/psql')

client.connect();

const home= function (req, res, next) {
    client.query('SELECT * FROM person WHERE ID = 1', [1], function (err, result) {
        if (err) {
            console.log(err);
            res.status(400).send(err);
        }
        res.status(200).send(result.rows);
    });
}

module.exports = home