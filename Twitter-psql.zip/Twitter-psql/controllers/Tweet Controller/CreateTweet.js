const client = require('../../connection/psql');
const login_user = require('../User controller/login')
const email = require('../User controller/login')
const express = require('express-session');
const { json } = require('body-parser');
const auth = require('../../routes/auth/auth/index')

const user=function (req, res, next) {
    auth
     client.query('INSERT INTO twitter_post (post) VALUES($1)',[req.body.post],function(err,result){
        client.query('UPDATE twitter_user SET post_id=$2 AND post = $1 WHERE user_id =1;',[client.query('SELECT id FROM twitter_post WHERE post=$1',[req.body.post]),client.query('SELECT id FROM twitter_post WHERE email=$1',[email])],function(err,result){
            if(err){
                console.log(err)
                res.status(404).json({
                    message:"Problem while Tweeting max word limit increased more than 500 word or post is empty",
                    error:{err},
                })
               }
             else{
               res.status(200).json({
                   message:"Tweeted Successfully",
                   error:{err}
               })
             }
            })
          })
}

module.exports = user