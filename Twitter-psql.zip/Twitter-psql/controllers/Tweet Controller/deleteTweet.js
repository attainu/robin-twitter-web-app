const client = require('../../connection/psql');
const login_user = require('../User controller/login')
const email = require('../User controller/login')
const express = require('express-session');
const { json } = require('body-parser');
const auth = require('../../routes/auth/auth/index')

const user=function (req, res, next) {
    auth
        client.query('DELETE FROM twitter_post WHERE id =$2;',[req.body.id],function(err,result){
            if(err){
                console.log(err)
                res.status(404).json({
                    message:"Problem while Tweeting max word limit increased more than 500 word or post is empty",
                    error:{err},
                })
               }
             else{
               res.status(200).json({
                   message:"Tweeted Successfully",
                   error:{err}
               })
             }
            }
         )
          }

module.exports = user