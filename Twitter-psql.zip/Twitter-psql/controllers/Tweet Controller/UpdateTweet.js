const express = require('express-session');
const { json } = require('body-parser');
const auth = require('../../routes/auth/auth/index');
const { use } = require('passport');

const user=function (req, res, next) {
    auth
        client.query('UPDATE twitter_post SET post= $2 WHERE id =$1;',[req.body.id,req.body.post],function(err,result){
            if(err){
                console.log(err)
                res.status(404).json({
                    message:"Problem while delete the Tweet",
                    error:{err},
                })
               }
             else{
               res.status(200).json({
                   message:"Updated Successfully",
                   error:{err}
               })
             }
            }
         )
          }
module.exports=user