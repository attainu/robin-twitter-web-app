const getOneUser = require("../../db/getOneUser");
const client = require('../../connection/psql')
const bcrypt = require('bcrypt')
const LocalStrategy = require('passport-local').Strategy;


module.exports=function(req,res){
  getOneUser;
  client.query('UPDATE twitter_user SET password = $1 WHERE email =$2;',[req.body.email,req.body.password],function(err,result){
     if(err){
         console.log(err)
         res.status(404).json({
             message:"Invalid password or credntials",
             error:{err},
         })
        }
      else{
        res.status(200).json({
            message:"Password Updated successfully",
            error:{err}
        })
      }
     }
  )
   }
