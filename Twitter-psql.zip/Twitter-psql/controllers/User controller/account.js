const client = require('../../connection/psql')
const bcrypt = require('bcrypt')
const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy;
const flash = require('flash')

module.exports = function (req, res, next) {
    if(req.isAuthenticated()){
        res.status(200).json({title: "Account", userData: req.user, userData: req.user, messages: {danger: req.flash('danger'), warning: req.flash('warning'), success: req.flash('success')}});
    }
    else{
        res.redirect('/login');
    }
};