const client = require('../../connection/psql')
const bcrypt = require('bcrypt')
const LocalStrategy = require('passport-local').Strategy;

// client.connect()

module.exports = function (req, res, next) {
    if(req.isAuthenticated()){
    res.status(200).json({
        message:"User successfully logged in"
    })
    }
    else{
    res.redirect('/login');
    }
    };