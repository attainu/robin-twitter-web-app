const client = require('../../connection/psql')
const bcrypt = require('bcrypt')
const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy;
const account = require('../User controller/auth')
const flash = require('flash')
const session = require('express-session');


module.exports = function (req, res, next) {
try{
    var email = req.body.email
    client.query('SELECT * FROM twitter_user WHERE email = $1;', [email],function isAuthenticated(err,result){
        if(err) {
            res.status(404).json({
                message:err
            })
            return done(err)
            } 
            if(result.rows[0] == null){
            res.status(404).json({
                message:"Incorrect login deails",
                error:err
            })
            }
            else{
            bcrypt.compare(req.body.password, result.rows[0].password, function(err, check) {
            if (err){
            res.status(404),json("Error while checkig password")
            console.log('Error while checking password');
            return done();
            }
            else if (check){
            res.status(200).json({
                message:"Successfully loggedin",
                data:[{email: check.valueOf(result.rows[0].email), firstName: check.valueOf(result.rows[0].firstName)}]
            })
            if (req.body.remember == true) {
                req.session.cookie.maxAge = 30 * 24 * 60 * 60 * 1000; // Cookie expires after 30 days
                } else {
                req.session.cookie.expires = false; // Cookie expires at end of session
                }
            }
            else{
            res.status(200).json({
                message:"Oops. Incorrect login details.",
            })
        }
    });
    }
       passport.serializeUser(function(user, done) {
        return done(null, user);
        });
        passport.deserializeUser(function(user, done) {
        return done(null, user);
        });
    })

}
    
catch(err){
res.status(404).json({
    message:err
})
}};



