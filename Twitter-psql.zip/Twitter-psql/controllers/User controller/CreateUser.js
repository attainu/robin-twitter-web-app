const client = require('../../connection/psql')
const bcrypt = require('bcrypt')
const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy;
const createTable = require('../../db/userStructure')
const express = require('express');
const app = express();
const flash = require('flash')


app.use(require('body-parser').urlencoded({ extended: true }));
module.exports=async (req,res)=>{
client.query(createTable);
try{
await client.query('BEGIN')
 var pwd = await bcrypt.hash(req.body.password, 5);
 await JSON.stringify(client.query('SELECT count(*) AS num FROM twitter_user WHERE email = $1;', [req.body.email], function(err, result) {
 if(result.rows[0]==null){
 req.flash('warning', "This email address is already registered.")
 res.status(404).json({
   message:"This email address is already registered.",
   error:err
 })
 }
 else{
 client.query('INSERT INTO twitter_user (firstName, lastName, email, password) VALUES ($1, $2, $3, $4);', [req.body.firstName, req.body.lastName, req.body.email, pwd],async function(err, result) {
  if (err) {
    console.log(err);
    res.status(404).json({err});
    return;
}
 else {
 
 await client.query('COMMIT')
 console.log(result.rows)
 res.status(200).json({
   message:"User Successfully created",
   err:null
 })
 req.flash('success','User created.')
 res.redirect('/login');
 return;
 }
 });
 }
 }));
 } 
 catch(e){throw(e)}
}




