const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);
const mongoose = require('mongoose');
const loginUser=require('./controllers/User controller/login')
const auth = require('./controllers/User controller/auth');
const express = require('express');
const session = require('express-session');
const app = express();
const indexRouter = require('./routes/psql_router/routes');
const passport = require('passport')
const bodyParser = require('body-parser')
const dotenv = require('dotenv');
const cookieParser=require('cookie-parser')
const flash = require('flash')

dotenv.config({});
// mongoose.connect('mongodb://localhost/mongo-games')
//     .then(() => console.log('Now connected to MongoDB!'))
//     .catch(err => console.error('Something went wrong', err));

    //Error Handler
app.use(function(err,req,res,next){
    res.status(err.status||500);

    res.json({
        message:err.message,
        error:req.app.get('env') === 'devlopment' ? err:{}
    })
})

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// Express session
// app.use(session({ secret: process.env.SECRET }));
app.use(cookieParser());
app.use(session({
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
  }))

app.use(require('cookie-parser')())
app.use(require('body-parser').urlencoded({ extended: true }));
app.use(flash())

app.use(express.json());
app.use('/api/login', loginUser);
app.use('/api/auth', auth);
app.use('/api/',indexRouter)

//passport

app.use(passport.initialize());
app.use(passport.session());
 
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Listening on port ${port}...`));


module.export=app
app.use(require('./routes/psql_router/routes.js'))
