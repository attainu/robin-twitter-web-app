const express = require('express');
const homecontroller = require('../../controllers/homecontroller');
const routes=express.Router();
// const deletePost = require('../../controllers/deletePost');
const CreateUser = require('../../controllers/User controller/CreateUser');
const accountController = require('../../controllers/User controller/auth');
const loginController = require('../../controllers/User controller/login');
const { Router } = require('express');
const UpdatePassword = require('../../controllers/User controller/UpdatePassword');
const CreateTweetController = require('../../controllers/Tweet Controller/CreateTweet')
const deleteTweetController = require('../../controllers/Tweet Controller/deleteTweet')
const updateTweetController = require('../../controllers/Tweet Controller/UpdateTweet')

//User Controller
routes.post('/signup',CreateUser)
routes.get('/account',accountController)
routes.get('/login',loginController)
routes.get('/forgotpassword',UpdatePassword )



//Tweet Controller
routes.post('/createTweet',CreateTweetController)
routes.get('/',homecontroller);
routes.get('/deleteTweet',deleteTweetController)
routes.get('/updateTweet',updateTweetController)

module.exports=routes