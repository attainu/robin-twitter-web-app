const client = require('../../../connection/psql');
const login_user = require('../../../controllers/User controller/login')
const email = require('../../../controllers/User controller/login')
const express = require('express-session');
const { json } = require('body-parser');


async function loggedIn(err,check) {
    if(login_user.message=="Successfully loggedin"){
            res.status(200).json({
                message:"Keep Tweeting"
            })
        }
        else{
                res.status(404).json({
                    message:"You are not logged in. Please login first",
                    error:err
                })
            }
        }