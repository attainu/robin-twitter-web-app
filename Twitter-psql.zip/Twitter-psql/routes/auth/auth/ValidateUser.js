const Promise = require('promise')


function validatePassword(password, minCharacters) {
    return new Promise(function(resolve, reject) {
      if (typeof (password) !== 'string') {
        reject('password must be a string');
      }
      else if (password.length < minCharacters) {
        reject('password must be at least ' + minCharacters + ' characters long');
      }
      else {
        resolve();
      }
    });
  }
  

function validateEmail(email) {
    return new Promise(function(resolve, reject) {
      if (typeof (email) !== 'string') {
        reject('email must be a string');
      }
      else {
        var re = new RegExp(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/);
        if (re.test(email)) {
          resolve();
        }
        else {
          reject('provided email does not match proper email format');
        }
      }
    });
  }

module.exports = function validateUserData(data) {
    return new Promise(function(resolve, reject) {
      if (!data.password || !data.email) {
        reject('email and/or password missing')
      }
      else {
        validatePassword(data.password, 6)
          .then(function() {
            return validateEmail(data.email);
          })
          .then(function() {
            resolve();
          })
          .catch(function(err) {
            reject(err);
          });
      }
    });
  }