const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy;
const client = require('../../connection/psql')

// const client =client.connect()
module.exports=passport.use('local', new LocalStrategy({passReqToCallback : true}, (req, email, password, done) => {
 
    loginAttempt();
    async function loginAttempt(req,res) {
    try{
    await client.query('BEGIN')
    var currentAccountsData = await JSON.stringify(client.query('SELECT user_id, firstName, email, password FROM twitter_user WHERE email=$1', [req.body.email], function(err, result) {
    
    if(err) {
    res.status(404).json({
        message:err
    })
    return done(err)
    } 
    if(result.rows[0] == null){
    res.status(404).json({
        message:"Incorrect login deails",
        error:err
    })
    req.flash('danger', "Oops. Incorrect login details.");
    return done(null, false);
    }
    else{
    bcrypt.compare(password, result.rows[0].password, function(err, check) {
    if (err){
    res.status(404),json("Error while checkig password")
    console.log('Error while checking password');
    return done();
    }
    else if (check){
    res.status(200).json({
        message:[{email: result.rows[0].email, firstName: result.rows[0].firstName}]
    })
    return done(null, [{email: result.rows[0].email, firstName: result.rows[0].firstName}]);
    }
    else{
    res.status(200).json({
        message:"Oops. Incorrect login details.",
    })
    req.flash('danger', "Oops. Incorrect login details.");
    return done(null, false);
    }
    });
    }
    }))
    }
    
    catch(e){throw (e);}
    };
    
   }
   ))
   passport.serializeUser(function(user, done) {
   return done(null, user);
   });
   passport.deserializeUser(function(user, done) {
   return done(null, user);
   });