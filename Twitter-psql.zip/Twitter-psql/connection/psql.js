const { Client } = require('pg');
const dotenv = require('dotenv');



dotenv.config({});
const connectionString = process.env.POSTGRES_URL;
console.log(connectionString)


const client = new Client({
    connectionString: connectionString,
});

client.connect()

module.exports=client