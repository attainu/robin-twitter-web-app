const client = require('../connection/psql');
const Tweet = require('../models/Tweet');
const moment = require('moment');

// client.connect()


const queryText =
`CREATE TABLE IF NOT EXISTS
  twitter_user(
    user_id BIGSERIAL NOT NULL  PRIMARY KEY,
    email VARCHAR(200) NOT NULL,
    password VARCHAR(200) NOT NULL,
    firstName VARCHAR(200) NOT NULL,
    lastName VARCHAR(200) NOT NULL,
    posts  VARCHAR(500),
    post_id BIGINT REFERENCES twitter_post (id),
    CONSTRAINT emailuni UNIQUE(email)
  );`;

  module.exports = queryText;











































  