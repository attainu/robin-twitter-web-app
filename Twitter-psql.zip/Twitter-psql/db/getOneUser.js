const client  = require('../connection/psql')
const Promise = require('promise')

client.connect()

module.exports={
    getOne:function(req,res) {
        return new Promise(function(resolve, reject) {
          if (!req.body.user_id && !req.body.email) {
            reject('error: must provide id or email')
          }
          else {
            if (data.id) {
              client.query('SELECT id  FROM twitter_user where id= $1',[req.body.user_id])
                .then(function(result) {
                  delete result.password;
                  resolve(result);
                })
                .catch(function(err) {3
                  reject(err);
                });
            }
            else if (data.email) {
                client.query('SELECT email FROM twitter_user where email= $1',[req.body.email])
                .then(function(result) {
                  delete result.password;
                  resolve(result);
                })
                .catch(function(err) {
                  reject(err);
                });
            }
          }
        });
      },
    }