const express = require('express');
const {check} = require('express-validator');
const Tweet = require('../controllers/tweet');
const validate = require('../common/validate');
const autenticate = require('../common/passport');


const router = express.Router();
 
router.post('/createTweet', [
    check('body').not().isEmpty().withMessage('Content should not be empty!'),
], validate, autenticate, Tweet.create);

//view all tweets
router.get("/viewAll", Tweet.viewAll);

//view user tweet
router.get('/viewTweets',autenticate,Tweet.view);

//view particular tweet
router.post('/viewTweet',[
	check('id').not().isEmpty().withMessage('Id should not be empty!'), //tweet id
	],validate,autenticate,Tweet.viewOne);

//update tweet
router.post('/editTweet',[
	check('id').not().isEmpty().withMessage('Id should not be empty!'),
	check('body').not().isEmpty().withMessage('Content should not be empty!'), //tweet id
	],validate,autenticate,Tweet.edit);

//delete particular tweet
router.delete('/deleteTweet',[
	check('id').not().isEmpty().withMessage('Id should not be empty!'), //tweet id
	],validate,autenticate,Tweet.delete);

//add favorites
router.post('/addFav',[
	check('id').not().isEmpty().withMessage('Id should not be empty!'), //tweet id
	],validate,autenticate,Tweet.add);

//delet favorites
router.post('/deleteFav',[
	check('id').not().isEmpty().withMessage('Id should not be empty!'), //tweet id
	],validate,autenticate,Tweet.destroy);

module.exports = router;