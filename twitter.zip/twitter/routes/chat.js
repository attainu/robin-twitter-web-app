const express = require('express');
const {check} = require('express-validator');
const Chat = require('../controllers/chat');
const validate = require('../common/validate');
const autenticate = require('../common/passport');

const router = express.Router();
 
router.post('/addChat', [
    check('message').not().isEmpty().withMessage('Message is required!'),
    check('receiver').not().isEmpty().withMessage('Receiver id is required!'),   
], validate, autenticate,Chat.add);

router.get('/viewChat', validate, autenticate,Chat.viewAll);

router.get('/getReceiverId',Chat.getReceiver);

router.post('/deleteChat', [
    check('id').not().isEmpty().withMessage('Message id is required!'), //messageid 
], validate, autenticate,Chat.delete);

module.exports = router;
