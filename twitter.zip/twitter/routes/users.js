const express = require('express');
const {check} = require('express-validator');
const User = require('../controllers/users');
const validate = require('../common/validate');
const autenticate = require('../common/passport');

const router = express.Router();

router.get('/', (req, res) => {
    res.json({message: "You are in the Auth Endpoint. Register or Login to test Authentication."});
});
 
router.post('/register', [
    check('email').isEmail().withMessage('Enter a valid email address!'),
    check('username').not().isEmpty().withMessage('You username is required!'),
    check('password').not().isEmpty().isLength({min: 6}).withMessage('Must be at least 6 chars long!')
], validate, User.register);

router.post("/login", [
    check('email').isEmail().withMessage('Enter a valid email address!'),
    check('password').not().isEmpty(),
], validate, User.login);

router.post('/getUsers',[
	check('username').not().isEmpty().withMessage('Username is required!'),
	],validate, autenticate,User.getUser)

router.post('/addFollow', [
    check('id').not().isEmpty().withMessage('Id is required!'),  //user id
], validate, autenticate,User.addFollow);

module.exports = router;
