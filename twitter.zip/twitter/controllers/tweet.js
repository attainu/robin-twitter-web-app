//model
const Tweet = require('../models/tweet');
const crypto = require('crypto');
const User = require('../models/users');

//create tweet
// @route POST /tweet/createTweet
exports.create = (req,res) => {
	const userId = req.user._id;

	const data = {
		user : userId,
		body : req.body.body
	}
	
    const newTweet = new Tweet(data);
    newTweet.save()
        .then(user => {
        	User.updateOne({_id: userId},{$inc : {tweets : 1}})
        	.then(addCount => {
        		if(addCount.nModified == 1) {
        			res.json({success: true, message:'Added Successfully!'})
        		} else {
        			res.json({success : false,message : 'Something went wrong!'})
        		}
        	}); // add tweets count
        	
        })
        .catch(err => res.json({success: false, message:err.message}));
        
};

//view all tweets
// @route POST /tweet/viewAll
exports.viewAll = (req,res) => {
	Tweet.find({})
	.then(tweets => {

		var arr =[];

		tweets.forEach((e) => {
			var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
			var mystr = mykey.update(String(e._id), 'utf8', 'hex')
			mystr += mykey.final('hex');


			arr.push({"Tweet id":mystr,"Content":e.body});

		})

		res.json({success: true,data :arr})	
	})
	.catch(err => res.json({success: false,message:err.message}));

};

//view tweets
// @route POST /tweet/viewTweets
exports.view = (req,res) => {
	let userId = req.user._id;

	Tweet.find({user: userId})
	.then(tweets => {

		var arr =[];

		tweets.forEach((e) => {
			var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
			var mystr = mykey.update(String(e._id), 'utf8', 'hex')
			mystr += mykey.final('hex');

			arr.push({"Tweet id":mystr,"Body":e.body,"Favorites":e.favorites,"Favoriters":e.favoriters,"Comments":e.comments,"FavoritesCount":e.favoritesCount})
		})

		res.json({success: true,data :arr})	
	})
	.catch(err => res.json({success: false,message:err.message}));

};

//view particular tweet
// @route POST /tweet/viewTweet
exports.viewOne = (req,res) => {
	let userId = req.user._id;
	let id =  req.body.id;     //Tweet id

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Tweet.findOne({"_id": mystr,"user":userId},{_id:0,user:0})
		.then(tweet => {
			res.json({success: true,data: tweet})
		})	
		.catch(err => res.json({success: false, message: err.message}));
};

//edit tweet
// @route POST /tweet/editTweet
exports.edit = (req,res) => {
	let userId = req.user._id;
	let id =  req.body.id;     //Tweet id

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Tweet.updateOne({"_id": mystr,"user":userId},{$set : {"body" :req.body.content}})
		.then(tweet => {
			if(tweet.nModified == 1) {
				res.json({success: true,message : 'Edited!'})
			} else {
				res.json({success: false,message : 'Error while editing Tweet!'})
			}
		})	
		.catch(err => res.json({success: false, message: err.message}));
};

//delete tweet
// @route POST /tweet/deleteTweet
exports.delete = (req,res) => {
	let userId = req.user._id;
	let id =  req.body.id;     //Tweet id

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Tweet.deleteOne({"_id": mystr,"user":userId})
		.then(tweet => {
			console.log(tweet)
			if(tweet.deletedCount == 1) {
				res.json({success: true,message : 'Dleted!'})
			} else {
				res.json({success: false,message : 'Error while deleting Tweet!'})
			}
		})	
		.catch(err => res.json({success: false, message: err.message}));
};

//add favourites
// @route POST /tweet/addFav
exports.add = (req,res) => {
	let userId = req.user._id;
	let id =  req.body.id;

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Tweet.findOne({"_id":mystr},{_id:0,user:0})
		.then(tweet => {
			let favCount = parseInt(tweet.favoritesCount);
			if (tweet.favorites.indexOf(userId) === -1) {
			    Tweet.updateOne({"_id":mystr},{$push: {"favorites": userId,"favoriters":userId },$set : {favoritesCount : favCount+1}},(err,docs) => {
			    	if(docs.nModified == 1) {
			    		res.json({success: true, message : 'Favourties added!'})
			    	}  else {
			    		res.json({success:false,message:err})
			    	}
			    })
			  } else {
			    res.json({success : false, message: 'Already Added!'})
			  }
			})
};

//delete favourites
// @route POST /tweet/deleteFav
exports.destroy = (req,res) => {
	let userId = req.user._id;
	let id =  req.body.id;

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Tweet.findOne({"_id":mystr},{_id:0,user:0})
		.then(tweet => {
			let favCount = parseInt(tweet.favoritesCount);
			if (tweet.favorites.indexOf(userId) === 1) {
			    Tweet.updateOne({"_id":mystr},{$pull: {"favorites": userId,"favoriters":userId },$set : {favoritesCount : favCount-1}},(err,docs) => {
			    	if(docs.nModified == 1) {
			    		res.json({success: true, message : 'Favourties deleted!'})
			    	}  else {
			    		res.json({success:false,message:err})
			    	}
			    })
			  } else {
			    res.json({success : false, message: 'Already deleted!'})
			  }
			})
};