//model
const User = require('../models/users');
const Tweet = require('../models/tweet');
const mongoose = require('mongoose');

// @route POST /register
exports.register = (req, res) => {
    User.findOne({email: req.body.email})
        .then(user => {

            if (user) return res.json({message: 'The email address is already registerd!.'});

            const newUser = new User(req.body);
            newUser.save()
                .then(user => res.json({success: true, message:'Registerd successfully!'}))
                .catch(err => res.json({success : false, message:err.message}));
        })
        .catch(err => res.json({success: false, message: err.message}));
};

// @route POST /login
exports.login = (req, res) => {
    User.findOne({email: req.body.email})
        .then(user => {
            if (!user) return res.status(401).json({msg: 'The email address ' + req.body.email + ' is not associated with any account.'});

            if (!user.comparePassword(req.body.password)) return res.json({message: 'Invalid email or password'});

            res.json({success: true,token: user.generateJWT(),message:'successfully Loggged In!'});
        })
        .catch(err => res.json({message: err.message}));
};

//@route POST /getUsers
exports.getUser = (req,res) => {
    let userId = req.user._id;
   
    User.find()
        .then(users => {
            var arr = [];
            users.forEach(e => {
                console.log(e._id,'wwwwwww')
                console.log(userId,'1234')
                if(String(e._id) != String(userId)) {
                    arr.push({"User":e._id})
                }
            }) 
            res.json({success: true,data: arr});
        }).catch(err => res.json({success:false,message:err.message}))
}

// @route POST /addFollw
exports.addFollow = (req,res) => {
    let userId = req.user._id; 
    let id = req.body.id;   //user id

    User.findOne({_id:id},(err,follower) => {
        User.findOne({_id:userId},(err,following) => {
            if (follower.following.indexOf(userId) === -1 && following.followers.indexOf(id)) {
                User.updateOne({"_id":id},{$push: {"following" : userId}})
                    .then(user => {
                        User.updateOne({"_id":userId},{$push: {"followers" : id}})
                        .then(user => {
                            res.json({success:true,message:'Added followers!'})
                        }).catch(err => res.json({success: false,message:err.message}));
                    }).catch(err => res.json({success: false,message:err.message}));
        } else {
            res.json({success:false,message:'Already follwed!'})
        }
            
        })  
    })
};
