//model
const Chat = require('../models/chat');
const crypto = require('crypto');
const User = require('../models/users');

//create chat
// @route POST /chat/addChat
exports.add = (req,res) => {
	const sender = req.user._id;

	const data = {
		sender : userId,
		message : req.body.message,
		receiver : req.body.receiver
	}
	
    const newChat = new Chat(data);
    newChat.save()
        .then(user => {
        	res.json({success: true, message:'Message Added Successfully!'})
        	
        })
        .catch(err => res.json({success: false, message:err.message}));
        
};

//view chats
// @route POST /chat/viewChat
exports.viewAll = (req,res) => {
	const sender = req.user._id;

	Chat.find({"sender": sender})
	.then(chats => {

		var arr =[];

		chats.forEach((e) => {
			var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
			var mystr = mykey.update(String(e._id), 'utf8', 'hex')
			mystr += mykey.final('hex');


			arr.push({"Message id":mystr,"Message":e.message});

		})

		res.json({success: true,data :arr})	
	})
	.catch(err => res.json({success: false,message:err.message}));

};

//get receiver id
// @route POST /chat/getReceiverId
exports.getReceiver = (req,res) => {
	User.find({})
	.then(users => {

		var arr =[];

		users.forEach((e) => {
			var mykey = crypto.createCipher('aes-128-cbc', 'mypassword');
			var mystr = mykey.update(String(e._id), 'utf8', 'hex')
			mystr += mykey.final('hex');


			arr.push({"Receiver id":mystr});

		})

		res.json({success: true,data :arr})	
	})
	.catch(err => res.json({success: false,message:err.message}));
};

//delete chat
// @route POST /chat/deleteChat
exports.delete = (req,res) => {
	let sender = req.user._id;
	let id =  req.body.id;   //message id

	var mykey = crypto.createDecipher('aes-128-cbc', 'mypassword');
	var mystr = mykey.update(id, 'hex', 'utf8')
	mystr += mykey.final('utf8');

	Chat.deleteOne({"_id": mystr})
		.then(chat => {
			if(chat.deletedCount == 1) {
				res.json({success: true,message : 'Deleted!'})
			} else {
				res.json({success: false,message : 'Error while deleting Tweet!'})
			}
		})	
		.catch(err => res.json({success: false, message: err.message}));
};
