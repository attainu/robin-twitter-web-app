const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const TweetSchema = new Schema(
  {
    body: { type: String, default: "", trim: true, maxlength: 280 },
    user: { type: Schema.ObjectId, ref: "User" },
    comments: [
      {
        body: { type: String, maxlength: 280 },
        user: { type: Schema.ObjectId, ref: "User" },
        commenterName: { type: String },
        createdAt: { type: Date, default: Date.now() }
      }
    ],
    tags: { type: [String] },
    favorites: [{ type: Schema.ObjectId, ref: "User" }],
    favoriters: [{ type: Schema.ObjectId, ref: "User" }],
    favoritesCount: Number,
    createdAt: { type: Date, default: Date.now }
  },{ "versionKey": false }
);

const tweet = mongoose.model('Tweet',TweetSchema);

module.exports = tweet;